
<html>
<head>
    <meta charset="utf-8">
    <title>ژاوی - ورود</title>
    <meta content="ژاوی - صفحه ی ورود کاربر" name="description">
    <meta content="ژاوی , ورود , صفحه ی ورود ژاوی" name="keywords">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/9067ae8a47.js" crossorigin="anonymous"></script>
    <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/icon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/icon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/icon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/icon/site.webmanifest')); ?>">
    <link href="<?php echo e(asset('assets/icon/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Norican&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Odibee+Sans&display=swap" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
   <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login.css')); ?>">
    <link href="<?php echo e(asset('css/sort.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">

</head>
<body>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<div class="container">
    <div class="row">
        <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
            <h5 class="text-center" id="h5g"><img src="<?php echo e(asset('assets/icon/lls.png')); ?>" style="width: 100px;" height="100px"></h5>
            <div class="card card-signin my-5">
                <div class="card-body">
                    <h5 class="card-title text-center" id="cardt1">ورود به حساب کاربری</h5>
                    <div class="alert-danger">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]]); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

                        <!-- Validation Errors -->
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger" style="direction: rtl;border-radius: 0px;background-color: red;color: white">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <form class="form-signin" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-label-group" id="drf">
                            <input placeholder="ایمیل خود را وارد کنید" id="email" type="text" class="form-control" name="email" :value="old('email')" required autofocus>
                            <label  for="email" :value="__('Email')" id="email">ایمیل خود را وارد کنید</label>
                        </div>

                        <div class="form-label-group" id="drf">
                            <input type="password" name="password" id="password" class="form-control" placeholder="رمز عبور" required
                                   required autocomplete="current-password">
                            <label for="password" id="usernamelabel" :value="__('Password')">رمز عبور</label>
                        </div>
                        <div class="row">
                            
                            <div class="custom-control custom-checkbox mb-3" id="mb31">
                                <input id="remember_me" type="checkbox" name="remember">
                                <span class="ml-2 text-sm text-gray-600" style="padding: 5px">من را به خاطر بسپار</span>
                            </div>
                        </div>
                        <button class="btn btn-lg btn-block" type="submit" id="subid" style="font-weight: normal">ورود</button>
                        <br><br>
                        <?php if(Route::has('password.request')): ?>
                        <a href="<?php echo e(route('password.request')); ?>"><p style="text-align: center;font-size: 14px" id="uyti">فراموشی رمز عبور</p></a>
                        <?php endif; ?>
                       <a href="<?php echo e(route('register')); ?>"><p style="text-align: center;font-size: 14px" id="uyti">حساب کاربری ندارید ؟؟ ساخت حساب کاربری</p></a>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/purecounter/purecounter.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
<?php /**PATH C:\Users\yasin\PhpstormProjects\podcast\resources\views/auth/login.blade.php ENDPATH**/ ?>