
<header id="header" class="header container-fluid fixed-top">
    <div class="container-fluid d-flex align-items-center justify-content-between">
        <div class="logo d-flex align-items-left">
            <a href="<?php echo e(route('index')); ?>"><span style="margin-right: 10px" id="spannoe"><img src="<?php echo e(asset('lls.jpg')); ?>" width="40px" id="nowimf"></span></a>
            <form method="get" action="<?php echo e(route('getinallsnow')); ?>">
                <input type="text" name="q" placeholder="جست و جو کنید" id="searchnow" maxlength="200" required>
            </form>
        </div>
        <nav id="navbar" class="navbar">
            <ul>
                <?php
                $alllinks = \Illuminate\Support\Facades\DB::table('links')->where('status','link')->get()->toArray();
                $allmatlab = \Illuminate\Support\Facades\DB::table('links')->where('status','dropdown')->where('for',"matlab")->get()->toArray();
                ?>
                <?php $__currentLoopData = $alllinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $linked = $link->link;
$slug = $link->slug;
                    ?>
                <li title="<?php echo $linked; ?>"><a class="nav-link scrollto active getstarted" href="<?php echo e(route('getscons',['var'=>$slug,'sort'=>'newest'])); ?>" style="font-size: 15px;color: #1a202c;font-weight: normal" id="wwer"><?php echo e($linked); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <li class="dropdown"><a href="#" class="getstarted" id="wwer"><i class="fas fa-chevron-down" style="margin: 0px 5px;font-size: 10px;color: #1a202c"></i><span style="font-size: 15px;color: #1a202c;font-weight: normal">مطالب</span></a>
                     <ul>
                         <?php $__currentLoopData = $allmatlab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linkz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php
                                 $linked = $linkz->link;
 $slugs = $linkz->slug;
                             ?>
                             <li><a href="<?php echo e(route('getscons',['var'=>$slugs,'sort'=>'newest'])); ?>"><?php echo e($linked); ?></a></li>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </ul>
                 </li>
                
                
                <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                      
                    <?php if(\Illuminate\Support\Facades\Auth::user()->role == 'USR'): ?>
                        <li>
                            <a class="getstarted scrollto" id="createnows" href="<?php echo e(route('dashboard')); ?>#changeidt" type="button" style="font-family: Vazir">ویرایش پروفایل</a>
                        </li>
                        <?php endif; ?>
                        <li>
                            <form method="post" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                            <button type="submit" class="getstarted scrollto" id="createnowsexit" style="font-family: Vazir;outline: none;border: 0px">خروج از حساب کاربری</button>
                            </form>
                        </li>
                 <?php
                 if (\Illuminate\Support\Facades\Auth::check()){
    if (\Illuminate\Support\Facades\Auth::user()->role == 'WRT'){
        $rol = ' <li>
                            <a class="getstarted scrollto" data-toggle="modal" data-target="#myModal" id="createnows" type="button" style="font-family: Vazir"><i class="fas fa-plus-circle"></i> پست</a>
                        </li>';
        $edm = '<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body" id="modalbodys">
                <div class="row col-md-12 text-center" id="nowiconin">
                    <div><a href="'.route('contentuser').'"><span><i class="fas fa-file-alt"><br><span style="font-size: 12px">متن</span></i></span></a></div>
                </div>
                <br>
                <div class="container-fluid text-center">
                    <button class="close" data-dismiss="modal" id="modalclosebutton">بستن</button>
                </div>
            </div>
        </div>

    </div>
</div>';
    }
    }
          if (\Illuminate\Support\Facades\Auth::check()){
    if (\Illuminate\Support\Facades\Auth::user()->role == 'ADM' and \Illuminate\Support\Facades\Auth::id() == 1){
        $adm ='<li>
                            <a class="getstarted scrollto" id="createnows" href="'.route('Adminhome').'" type="button" style="font-family: Vazir">ادمین</a>
                        </li> ';
    }
}
                 ?>
                    <?php echo $rol ?? null; ?>

                        <?php echo $adm ?? null; ?>

                        <li>
                            <?php
                            $prof = \Illuminate\Support\Facades\Auth::user()->profile ?? null;
$pic = explode('public',$prof)[1] ?? null;
                            ?>
                            <a class="scrollto" id="profimagenow" href="<?php echo e(route('dashboard')); ?>" style="font-family: Vazir"><img <?php if(!empty(\Illuminate\Support\Facades\Auth::user()->profile)): ?> src="<?php echo e($pic); ?>" <?php else: ?> src="<?php echo e(asset('default.png')); ?>" <?php endif; ?> width="35px"></a>
                        </li>
                    <?php else: ?>
                        <li>
                            <a class="getstarted scrollto" id="getstartedloginbu" href="<?php echo e(route('login')); ?>" style="font-family: Vazir">ورود</a>
                        </li>
                        <li>
                            <a class="getstarted scrollto" href="<?php echo e(route('register')); ?>" style="font-family: Vazir">ثبت نام</a>
                        </li>                    <?php endif; ?>
                <?php endif; ?>
                <li id="afterscroll">
                    <a class="getstarted scrollto" id="wwer">خانه<span style="padding-left: 5px">🏠</span></a>
                </li>
                <li id="afterscroll">
                    <a href="" class="getstarted scrollto" id="wwer" >کتاب الکترونیک<span style="padding-left: 5px">📚</span></a>
                </li>
                <li id="afterscroll">
                    <a href="" class="getstarted scrollto" id="wwer">سوالات<span style="padding-left: 5px">❓</span></a>
                </li>
                <li id="afterscroll">
                    <a href="" class="getstarted scrollto" id="wwer">دوره ها<span style="padding-left: 5px">👨‍🏫</span></a>
                </li>
                <li id="afterscroll">
                    <a href="" class="getstarted scrollto" id="wwer">پادکست ها<span style="padding-left: 5px">🎙️</span></a>
                </li>
                <li id="afterscroll">
                    <a href="" class="getstarted scrollto" id="wwer">ویدئو ها<span style="padding-left: 5px">🎞️</span></a>
                </li>
                <li id="afterscroll">
                    <a href="" class="getstarted scrollto" id="wwer">دسته بندی ها<span style="padding-left: 5px">💡</span></a>
                </li>
            </ul>
            <i class="fas fa-bars mobile-nav-toggle"></i>
        </nav><!-- .navbar -->
    </div>
</header>
<?php echo $edm ?? null; ?>

<?php /**PATH C:\Users\yasin\PhpstormProjects\podcast\resources\views/header.blade.php ENDPATH**/ ?>