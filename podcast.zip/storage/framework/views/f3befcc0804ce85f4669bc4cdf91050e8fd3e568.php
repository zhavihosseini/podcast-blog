<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>show comment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>
<body>
<div class="container-fluid" style="background-color: #1e2125;color: white;font-weight: bold;">
    show Comment
</div>
<br>
<div class="container">
    <div class="row col-md-12">
        <div class="col-md-2">
            <?php
            $hash = new \Hashids\Hashids();
$enhash = $hash->encode($userid);
 $user = \App\Models\User::findOrFail($userid);
 $comment = $user->comment;

            ?>
    <form method="get" action="<?php echo e(route('showuserinfo')); ?>">
        <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
        <button>show this user</button>
    </form>
        </div>

        <div class="col-md-2">
            <?php if($comment == 'ok'): ?>
    <form method="post" action="<?php echo e(route('closecomment')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="val" value="no">
        <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
        <button>close comment</button>
    </form>
<?php elseif($comment == 'no'): ?>
                <form method="post" action="<?php echo e(route('closecomment')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="val" value="ok">
                    <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
                    <button style="background-color: green;color: white">Open Comment</button>
                </form>
            <?php endif; ?>
        </div>
        <div class="col-md-2">
            <form method="post" action="<?php echo e(route('deleteallcomment')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
                <button>delete all comment</button>
            </form>
        </div>
    </div>
    <br><br>
<div class="row col-md-12">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                status 1 from user (<?php echo e($notacceptcount); ?>)
            </div>
            <div class="card-body">
                <?php if(!empty($allnoaccpt)): ?>
                <?php $__currentLoopData = $allnoaccpt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usercmnts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $usercmnts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comnts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id = $comnts->id;
        $comment = $comnts->content;
        $time = $comnts->time;
        $date = \Morilog\Jalali\Jalalian::forge($time)->ago();
        $userid = $comnts->userid;
        $getsuser = \App\Models\User::find($userid);
    $username = $getsuser->name;
    $usr = $getsuser->username;
    $picuser= $getsuser->profile ?? null;
    if (empty($picuser)){
        $picuser = asset('default.png');
    }
    $ids = $id + 8846321;
    $hash = new \Hashids\Hashids();
    $enhash = $hash->encode($ids);
                        ?>
                            <form style="text-align: left" method="post" action="<?php echo e(route('deletethiscomment')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="val" value="<?php echo e($enhash); ?>">
                                <button>delete</button>
                            </form>
                            <form style="text-align: left" method="post" action="<?php echo e(route('okthiscommnet')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="val" value="<?php echo e($enhash); ?>">
                                <input type="hidden" name="var" value="2">
                                <button>Ok</button>
                            </form>
                            <div class="row col-md-12" style="background-color: #f3f2fd;direction: rtl">
                                <p style="padding: 8px"><span style="color: black;background-color: #d5d4e3;padding: 5px"><?php echo e($username); ?></span></p>
                                <p style="padding: 12px"><img src="<?php echo e($picuser); ?>" width="50px" height="50px" style="border-radius: 50%"><span style="padding-right: 10px"><?php echo e($comment); ?></span></p>
                                <span style="font-size: 12px;color: #8a8993;text-align: left;padding: 5px"><?php echo e($date); ?></span>
                            </div>
                            <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                all from user (<?php echo e($getfromusercount); ?>)
            </div>
            <div class="card-body" style="max-height: 500px;overflow: auto">
                <?php if(!empty($alluser)): ?>
                <?php $__currentLoopData = $alluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usercmnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $usercmnt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $id = $comnt->id;
    $comment = $comnt->content;
    $time = $comnt->time;
    $date = \Morilog\Jalali\Jalalian::forge($time)->ago();
    $userid = $comnt->userid;
    $getsuser = \App\Models\User::find($userid);
$username = $getsuser->name;
$usr = $getsuser->username;
$picuser= $getsuser->profile ?? null;
if (empty($picuser)){
    $picuser = asset('default.png');
}
$ids = $id + 8846321;
$hash = new \Hashids\Hashids();
$enhash = $hash->encode($ids);
                    ?>
                            <form style="text-align: left" method="post" action="<?php echo e(route('deletethiscomment')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="val" value="<?php echo e($enhash); ?>">
                                <button>delete</button>
                            </form>
                <div class="row col-md-12" style="background-color: #f3f2fd;direction: rtl">
                    <p style="padding: 8px"><span style="color: black;background-color: #d5d4e3;padding: 5px"><?php echo e($username); ?></span></p>
                    <p style="padding: 12px"><img src="<?php echo e($picuser); ?>" width="50px" height="50px" style="border-radius: 50%"><span style="padding-right: 10px"><?php echo e($comment); ?></span></p>
                    <span style="font-size: 12px;color: #8a8993;text-align: left;padding: 5px"><?php echo e($date); ?></span>
                </div>
                        <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\yasin\PhpstormProjects\podcast\resources\views/admin/showcomment.blade.php ENDPATH**/ ?>