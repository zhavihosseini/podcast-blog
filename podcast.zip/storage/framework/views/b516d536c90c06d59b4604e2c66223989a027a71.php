<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>Edit User</title>
</head>
<body>
<div class="container-fluid" style="background-color: #1e2125;color: white;">
    Edit User
</div>
<br><br>
<div class="container">
    <div class="row col-md-12 text-center">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $id = $usr['id'];
            $name = $usr['name'];
$username = $usr['username'];
$description = $usr['description'];
$semat = $usr['semat'];
$instagram = $usr['instagram'];
$email = $usr['email'];
$hash = new \Hashids\Hashids();
$enhash = $hash->encode($id);
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form method="post" action="<?php echo e(route('saveeditusers')); ?>">
            <?php echo csrf_field(); ?>
            <label for="name">Name : </label>
            <input type="text" name="name" value="<?php echo e($name); ?>">
            <br><br>
            <label for="Username">Username : </label>
            <input type="text" name="username" value="<?php echo e($username); ?>">
            <br><br>
            <label for="email">Email : </label>
            <input type="email" name="email" value="<?php echo e($email); ?>">
            <br><br>
            <label for="description">description : </label>
            <input type="text" name="description" value="<?php echo e($description); ?>">
            <br><br>
            <label for="semat">semat : </label>
            <input type="text" name="semat" value="<?php echo e($semat); ?>">
            <br><br>
            <label for="instagram">instagram : </label>
            <input type="text" name="instagram" value="<?php echo e($instagram); ?>">
            <br><br>
            <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
            <button type="submit">Submit</button>
        </form>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\yasin\PhpstormProjects\podcast\resources\views/admin/edituser.blade.php ENDPATH**/ ?>