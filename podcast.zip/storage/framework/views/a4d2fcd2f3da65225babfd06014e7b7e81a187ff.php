<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>Search in User</title>
</head>
<body>
<div class="container-fluid" style="background-color: #1e2125;color: white">
    Search in User <?php echo e($getresultcount); ?>

</div>
<section class="container-fluid">
    <div class="card-body">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">Id</th>
                <th scope="col">Name</th>
                <th scope="col">Username</th>
                <th scope="col">Email</th>
                <th scope="col">Role</th>
                <th scope="col">Email-Ver</th>
                <th scope="col">Profile</th>
                <th scope="col">Description</th>
                <th scope="col">Semat</th>
                <th scope="col">Instagram</th>
                <th scope="col">Status</th>
                <th scope="col">Show</th>
                <th scope="col">Edit</th>
                <th scope="col">Ban</th>
                <th scope="col">Delete</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $id = $user->id;
                    $name = $user->name;
                    $email = $user->email;
                    $role = $user->role;
                    $username = $user->username;
                    $emailver = $user->email_verified_at;
                    $profile = $user->profile ?? null;
                    $description = $user->description;
                    $semat = $user->semat;
                    $instagram = $user->instagram;
                    $img = explode('public',$profile)[1] ?? null;
                    if (empty($img)){
                        $img = asset('default.png');
                    }
                    $hash = new \Hashids\Hashids();
                    $enhash = $hash->encode($id);
                    $status = $user->status;
                     $vas = $id + 5456843;
            $envas = $hash->encode($vas);
                ?>
                <tr>
                    <th scope="row"><?php echo e($id); ?></th>
                    <td><?php echo e($name); ?></td>
                    <td><?php echo e($username); ?></td>
                    <td><?php echo e(\Illuminate\Support\Str::limit($email,20)); ?></td>
                    <td><?php echo e($role); ?></td>
                    <td><?php echo e($emailver ?? 'null'); ?></td>
                    <td><a target="_blank" href="<?php echo e($img); ?>"><img src="<?php echo e($img ?? 'null'); ?>" style="width: 50px;border-radius: 50%"></a></td>
                    <td><?php echo e(\Illuminate\Support\Str::limit($description,20)); ?></td>
                    <td><?php echo e($semat); ?></td>
                    <td><?php echo e($instagram); ?></td>
                    <td>
                        <?php if($status == 0): ?>
                            <p style="color: green">Ok</p>
                        <?php elseif($status == 1): ?>
                            <p style="color:red;">Banned !</p>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="get" action="<?php echo e(route('showuserinfo')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
                            <button type="submit">show</button>
                        </form>
                    </td>
                    <td> <form style="float: right" method="get" action="<?php echo e(route('edituser')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" style="border: 1px solid lightgrey;box-shadow: none;outline: none;background-color: transparent;">Edit</button>
                            <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
                        </form></td>
                    <td> <?php if($status == 0): ?>
                            <form style="float: right" method="post" action="<?php echo e(route('banneduser')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="value" value="1">
                                <input type="hidden" name="envas" value="<?php echo e($envas); ?>">
                                <button style="border: 1px solid lightgrey;box-shadow: none;outline: none;background-color: red;color: white">Ban</button>
                            </form>
                        <?php elseif($status == 1): ?>
                            <form style="float: right" method="post" action="<?php echo e(route('banneduser')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="value" value="0">
                                <input type="hidden" name="envas" value="<?php echo e($envas); ?>">
                                <button style="border: 1px solid lightgrey;box-shadow: none;outline: none;background-color: green;color: white">UnBan</button>
                            </form>
                        <?php endif; ?></td>
                    <td>  <form style="float: right" method="post" action="<?php echo e(route('deleteuser')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="var" value="<?php echo e($enhash); ?>">
                            <button style="border: 1px solid lightgrey;box-shadow: none;outline: none;background-color: transparent;">Delete</button>
                        </form></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php if(!empty($get)): ?>
            <div class="d-flex justify-content-center">
                <?php echo $get->appends(['sort'=>'department'])->links(); ?>

            </div>
        <?php endif; ?>
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\yasin\PhpstormProjects\podcast\resources\views/admin/searchinuser.blade.php ENDPATH**/ ?>